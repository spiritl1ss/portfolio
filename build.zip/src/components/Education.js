import React from "react";

const Education = () => {
  return (
    <section id="education">
      <h2>Education</h2>
      <p><strong>Bournemouth University</strong> - Software Engineering (2:2)</p>
      <p><strong>Weymouth College</strong> - IT Extended Diploma (DDM)</p>
    </section>
  );
};

export default Education;
