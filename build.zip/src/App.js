import React from "react";
import Main from "./pages/main";
import "./App.css";

function App() {
  console.log("App Component Rendered"); // Debugging
  return (
    <div>
      <Main />
    </div>
  );
}

export default App;
